<?php
use \CodeIgniter\Database\ConnectionInterface;
namespace App\Models;
class CrawlerModel extends \CodeIgniter\Model{
       
		
}