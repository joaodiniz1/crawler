<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2019-10-13 13:58:21 --> Call to undefined function form_open()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\View\View.php(235): include()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Common.php(175): CodeIgniter\View\View->render('calculator', Array, NULL)
#2 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(7): view('calculator')
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-10-13 16:36:16 --> Too few arguments to function App\Controllers\Calculator::calcPanel(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 844 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 16:36:25 --> Too few arguments to function App\Controllers\Calculator::calcPanel(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 844 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 16:36:34 --> Too few arguments to function App\Controllers\Calculator::calcPanel(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 844 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 16:36:45 --> Too few arguments to function App\Controllers\Calculator::calcPanel(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 844 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 16:36:46 --> Too few arguments to function App\Controllers\Calculator::calcPanel(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 844 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 16:36:46 --> Too few arguments to function App\Controllers\Calculator::calcPanel(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 844 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 16:36:50 --> Too few arguments to function App\Controllers\Calculator::calcPanel(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 844 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 16:37:05 --> Too few arguments to function App\Controllers\Calculator::index2(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 844 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index2()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 16:37:10 --> Too few arguments to function App\Controllers\Calculator::index2(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 844 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index2()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 17:59:30 --> syntax error, unexpected 'echo' (T_ECHO)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 17:59:31 --> syntax error, unexpected 'echo' (T_ECHO)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 18:20:30 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:20:51 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:22:28 --> Call to a member function get() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:22:34 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:22:59 --> Call to a member function request() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:23:28 --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 18:23:44 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:24:04 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:24:06 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:24:38 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:25:29 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:25:46 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:26:17 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:26:31 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:28:02 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:28:04 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:30:20 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:30:27 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:30:27 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:30:33 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:30:34 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:30:40 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:30:40 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:30:54 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:33:14 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:33:15 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:33:15 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:33:16 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:33:16 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:33:16 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:33:16 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:33:16 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:34:19 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:34:19 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:36:42 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:38:10 --> Call to undefined function form_open()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\View\View.php(235): include()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Common.php(175): CodeIgniter\View\View->render('calculator', Array, NULL)
#2 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(6): view('calculator')
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-10-13 18:38:10 --> Call to undefined function form_open()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\View\View.php(235): include()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Common.php(175): CodeIgniter\View\View->render('calculator', Array, NULL)
#2 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(6): view('calculator')
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-10-13 18:38:30 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:38:31 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:38:35 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:38:36 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:38:50 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:39:14 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:39:24 --> Call to undefined function form_open()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\View\View.php(235): include()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Common.php(175): CodeIgniter\View\View->render('calculator', Array, NULL)
#2 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(8): view('calculator')
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-10-13 18:39:37 --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 18:39:40 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:40:05 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(819): App\Controllers\Calculator->__construct()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(330): CodeIgniter\CodeIgniter->createController()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:40:07 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(819): App\Controllers\Calculator->__construct()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(330): CodeIgniter\CodeIgniter->createController()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:40:10 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(819): App\Controllers\Calculator->__construct()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(330): CodeIgniter\CodeIgniter->createController()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:40:15 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(819): App\Controllers\Calculator->__construct()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(330): CodeIgniter\CodeIgniter->createController()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:44:43 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:45:02 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:45:20 --> Call to undefined function form_open()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\View\View.php(235): include()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Common.php(175): CodeIgniter\View\View->render('calculator', Array, NULL)
#2 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(7): view('calculator')
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-10-13 18:45:20 --> Call to undefined function form_open()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\View\View.php(235): include()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Common.php(175): CodeIgniter\View\View->render('calculator', Array, NULL)
#2 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(7): view('calculator')
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-10-13 18:45:25 --> Call to undefined function form_open()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\View\View.php(235): include()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Common.php(175): CodeIgniter\View\View->render('calculator', Array, NULL)
#2 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(7): view('calculator')
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-10-13 18:45:25 --> Call to undefined function form_open()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\View\View.php(235): include()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Common.php(175): CodeIgniter\View\View->render('calculator', Array, NULL)
#2 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(7): view('calculator')
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-10-13 18:45:28 --> Call to undefined function form_open()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\View\View.php(235): include()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Common.php(175): CodeIgniter\View\View->render('calculator', Array, NULL)
#2 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(7): view('calculator')
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-10-13 18:45:42 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:45:43 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:45:51 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->index()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:47:26 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 18:47:26 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 18:48:54 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 18:50:48 --> Call to a member function get_post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:50:49 --> Call to a member function get_post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:50:49 --> Call to a member function get_post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:50:49 --> Call to a member function get_post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:50:57 --> Call to a member function get_post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:50:57 --> Call to a member function get_post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:51:02 --> Call to a member function get_post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:51:08 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 18:51:14 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:51:14 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:51:15 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:52:08 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:52:18 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:53:38 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:53:39 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:53:49 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:54:30 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:54:57 --> Call to undefined function App\Controllers\post()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:54:58 --> Call to undefined function App\Controllers\post()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:55:05 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 18:55:14 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:55:19 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:57:59 --> Call to undefined function App\Controllers\post()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 18:58:07 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:00:50 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:00:59 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:01:10 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:01:11 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:01:24 --> Call to undefined method App\Controllers\Calculator::post()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:04:56 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:05:06 --> Call to a member function post() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:05:40 --> Call to a member function getPost() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:06:14 --> Too few arguments to function App\Controllers\Calculator::__construct(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 819 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(819): App\Controllers\Calculator->__construct()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(330): CodeIgniter\CodeIgniter->createController()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:06:14 --> Too few arguments to function App\Controllers\Calculator::__construct(), 0 passed in C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php on line 819 and exactly 1 expected
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(819): App\Controllers\Calculator->__construct()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(330): CodeIgniter\CodeIgniter->createController()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:06:26 --> syntax error, unexpected 'ini_set' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 19:06:33 --> syntax error, unexpected 'ini_set' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 19:06:38 --> Call to a member function getPost() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:07:10 --> Call to a member function getPost() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:07:11 --> Call to a member function getPost() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:07:14 --> Call to a member function getPost() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:07:27 --> Call to a member function getVar() on null
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:11:49 --> syntax error, unexpected ';', expecting ')'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 19:11:50 --> syntax error, unexpected ';', expecting ')'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 19:15:02 --> explode() expects parameter 2 to be string, array given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'explode() expec...', 'C:\\xampp\\htdocs...', 12, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(12): explode('/', Array)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 19:15:14 --> syntax error, unexpected ';', expecting ')'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 19:15:14 --> syntax error, unexpected ';', expecting ')'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 19:15:15 --> syntax error, unexpected ';', expecting ')'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 19:15:32 --> syntax error, unexpected '$data' (T_VARIABLE)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 19:15:48 --> explode() expects parameter 2 to be string, array given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'explode() expec...', 'C:\\xampp\\htdocs...', 12, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(12): explode('/', Array)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 19:22:52 --> preg_match(): Compilation failed: quantifier does not follow a repeatable item at offset 1
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'preg_match(): C...', 'C:\\xampp\\htdocs...', 14, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(14): preg_match('/(+)(-)(*)/', 'foobarbaz', NULL, 256)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 19:52:27 --> syntax error, unexpected ';', expecting ')'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 19:52:28 --> syntax error, unexpected ';', expecting ')'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 19:57:08 --> syntax error, unexpected end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:57:29 --> syntax error, unexpected end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 19:57:39 --> syntax error, unexpected end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 20:01:17 --> syntax error, unexpected ''+'' (T_CONSTANT_ENCAPSED_STRING)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:03:26 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(22): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 22, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:05:02 --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) or const (T_CONST)
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:13:34 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(22): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 22, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:20:22 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(22): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 22, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:20:33 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(22): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 22, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:41:08 --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 134217736 bytes)
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-10-13 20:49:40 --> syntax error, unexpected ')', expecting ']'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:50:24 --> syntax error, unexpected ';', expecting ')'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:52:18 --> syntax error, unexpected ')', expecting variable (T_VARIABLE) or '{' or '$'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:54:31 --> syntax error, unexpected 'unset' (T_UNSET), expecting ';'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 20:55:43 --> syntax error, unexpected ';'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('calculator/calc...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('calculator/calc...')
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 21:00:39 --> array_unshift() expects parameter 1 to be array, int given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'array_unshift()...', 'C:\\xampp\\htdocs...', 47, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(47): array_unshift(3, Array)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 21:39:02 --> Cannot use a scalar value as an array
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(49): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Cannot use a sc...', 'C:\\xampp\\htdocs...', 49, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 21:42:34 --> Division by zero
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(36): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Division by zer...', 'C:\\xampp\\htdocs...', 36, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 21:47:35 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 49, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(49): number_format('', 2)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 21:49:47 --> Call to undefined function App\Controllers\float()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 21:49:51 --> Call to undefined function App\Controllers\float()
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 21:54:33 --> Division by zero
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(37): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Division by zer...', 'C:\\xampp\\htdocs...', 37, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 21:56:24 --> Division by zero
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(37): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Division by zer...', 'C:\\xampp\\htdocs...', 37, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 21:57:23 --> Modulo by zero
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-10-13 21:58:03 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('ERRO', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 21:58:13 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(33): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 33, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 21:58:59 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('ERRO', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 21:59:05 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(45): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 45, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 21:59:26 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('ERRO', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 21:59:28 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('ERRO', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 21:59:29 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('ERRO', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 22:00:25 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('ERRO', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 22:00:26 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('ERRO', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 22:01:05 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 22:04:51 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('ERRO', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 22:04:57 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(55): number_format('', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 22:05:18 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(30): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 30, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:05:22 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(30): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 30, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:09:15 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 59, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(59): number_format('', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 22:10:14 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:10:15 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:10:38 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(33): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 33, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:11:41 --> Cannot use a scalar value as an array
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(63): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Cannot use a sc...', 'C:\\xampp\\htdocs...', 63, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:12:23 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:12:28 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:12:29 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:12:58 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:12:59 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:13:08 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:13:08 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:13:09 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:17:59 --> number_format() expects parameter 1 to be float, string given
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'number_format()...', 'C:\\xampp\\htdocs...', 61, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(61): number_format('ERRO', 4)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 22:18:25 --> Cannot use try without catch or finally
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-10-13 22:18:26 --> Cannot use try without catch or finally
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-10-13 22:19:59 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:20:08 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:20:35 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:20:49 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:21:17 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:21:32 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:21:36 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:24:03 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(53): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 53, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:25:39 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:26:20 --> syntax error, unexpected 'if' (T_IF), expecting case (T_CASE) or default (T_DEFAULT) or '}'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:26:21 --> syntax error, unexpected 'if' (T_IF), expecting case (T_CASE) or default (T_DEFAULT) or '}'
#0 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-10-13 22:27:07 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(41): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 41, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:28:52 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:31:14 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:31:42 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:31:52 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:32:04 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:32:23 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 22:32:33 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(38): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 38, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:20:01 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(39): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 39, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:20:05 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(39): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 39, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:20:13 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(39): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 39, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:27:33 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(40): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 40, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:27:35 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(40): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 40, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:28:31 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(41): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 41, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:28:45 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(41): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 41, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:40:23 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(41): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 41, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:46:11 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(45): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 45, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:46:12 --> A non-numeric value encountered
#0 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(45): CodeIgniter\Debug\Exceptions->errorHandler(2, 'A non-numeric v...', 'C:\\xampp\\htdocs...', 45, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-10-13 23:55:40 --> count(): Parameter must be an array or an object that implements Countable
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'count(): Parame...', 'C:\\xampp\\htdocs...', 41, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(41): count(1)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 23:55:50 --> count(): Parameter must be an array or an object that implements Countable
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'count(): Parame...', 'C:\\xampp\\htdocs...', 41, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(41): count(1)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-10-13 23:55:59 --> count(): Parameter must be an array or an object that implements Countable
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'count(): Parame...', 'C:\\xampp\\htdocs...', 41, Array)
#1 C:\xampp\htdocs\joaodiniz1\calculator\app\Controllers\Calculator.php(41): count(1)
#2 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(844): App\Controllers\Calculator->calcPanel()
#3 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Calculator))
#4 C:\xampp\htdocs\joaodiniz1\calculator\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\joaodiniz1\calculator\public\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
