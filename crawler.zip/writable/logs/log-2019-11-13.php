<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2019-11-13 12:30:19 --> syntax error, unexpected '}', expecting end of file
#0 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(7): view('crawler')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 12:30:35 --> Invalid argument supplied for foreach()
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(82): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 82, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(7): view('crawler')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 12:30:42 --> count(): Parameter must be an array or an object that implements Countable
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(122): CodeIgniter\Debug\Exceptions->errorHandler(2, 'count(): Parame...', 'C:\\xampp\\htdocs...', 122, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(7): view('crawler')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 12:30:55 --> count(): Parameter must be an array or an object that implements Countable
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(122): CodeIgniter\Debug\Exceptions->errorHandler(2, 'count(): Parame...', 'C:\\xampp\\htdocs...', 122, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(7): view('crawler')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 12:31:36 --> count(): Parameter must be an array or an object that implements Countable
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(88): CodeIgniter\Debug\Exceptions->errorHandler(2, 'count(): Parame...', 'C:\\xampp\\htdocs...', 88, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(7): view('crawler')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 12:32:02 --> Invalid argument supplied for foreach()
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(82): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 82, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(7): view('crawler')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 12:47:44 --> Unknown database 'crawlerr'
#0 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(376): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(642): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseBuilder.php(1782): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(436): CodeIgniter\Database\BaseBuilder->get()
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(8): CodeIgniter\Model->findAll()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 12:47:50 --> Unknown database 'crawlerr'
#0 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(376): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(642): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseBuilder.php(1782): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(436): CodeIgniter\Database\BaseBuilder->get()
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(8): CodeIgniter\Model->findAll()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 12:47:55 --> Unknown database 'crawlerr'
#0 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(376): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(642): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseBuilder.php(1782): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(436): CodeIgniter\Database\BaseBuilder->get()
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(8): CodeIgniter\Model->findAll()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 12:48:02 --> Unknown database 'crawlerr'
#0 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(376): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(642): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseBuilder.php(1782): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(436): CodeIgniter\Database\BaseBuilder->get()
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(8): CodeIgniter\Model->findAll()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 12:48:46 --> Unknown database 'crawlerr'
#0 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(376): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(642): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseBuilder.php(1782): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(436): CodeIgniter\Database\BaseBuilder->get()
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(8): CodeIgniter\Model->findAll()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 12:49:08 --> Unknown database 'crawlerr'
#0 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(376): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(642): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseBuilder.php(1782): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(436): CodeIgniter\Database\BaseBuilder->get()
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): CodeIgniter\Model->findAll()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 12:56:16 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$'
#0 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 12:58:08 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::result()
#0 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include()
#1 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#2 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): view('crawler', Array)
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-11-13 12:59:05 --> Invalid argument supplied for foreach()
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(71): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 71, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): view('crawler', Array)
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 12:59:22 --> Argument 2 passed to view() must be of the type array, string given, called in C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php on line 9
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): view('crawler', '{"vehicles":{"c...')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 12:59:34 --> Argument 2 passed to view() must be of the type array, string given, called in C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php on line 9
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): view('crawler', '{"vehicles":{"c...')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 13:00:14 --> Argument 2 passed to view() must be of the type array, string given, called in C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php on line 9
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): view('crawler', '{"connID":{"aff...')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 13:00:24 --> Invalid argument supplied for foreach()
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(71): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 71, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(10): view('crawler', Array)
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 13:00:46 --> Invalid argument supplied for foreach()
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(71): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 71, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(10): view('crawler', Array)
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 13:00:50 --> Invalid argument supplied for foreach()
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(71): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 71, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(10): view('crawler', Array)
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 13:00:51 --> Invalid argument supplied for foreach()
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(71): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 71, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(10): view('crawler', Array)
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 13:01:14 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::result()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:01:15 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::result()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:03:48 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::result()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:04:08 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::result_array()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:05:06 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:05:06 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:05:26 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:05:36 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::result()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:05:44 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::result_array()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:06:02 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::result()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:06:08 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::result()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:07:31 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::get()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:10:01 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::findAll()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:12:59 --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$'
#0 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 13:13:03 --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$'
#0 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 13:13:15 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:14:01 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'order by id desc' at line 1
#0 C:\xampp\htdocs\crawlerstand\system\Database\MySQLi\Connection.php(329): mysqli->query('Select * from v...')
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(737): CodeIgniter\Database\MySQLi\Connection->execute('Select * from v...')
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(665): CodeIgniter\Database\BaseConnection->simpleQuery('Select * from v...')
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(1679): CodeIgniter\Database\BaseConnection->query('Select * from v...')
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): CodeIgniter\Model->__call('query', Array)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 13:14:07 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'orderby id desc' at line 1
#0 C:\xampp\htdocs\crawlerstand\system\Database\MySQLi\Connection.php(329): mysqli->query('Select * from v...')
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(737): CodeIgniter\Database\MySQLi\Connection->execute('Select * from v...')
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(665): CodeIgniter\Database\BaseConnection->simpleQuery('Select * from v...')
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(1679): CodeIgniter\Database\BaseConnection->query('Select * from v...')
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): CodeIgniter\Model->__call('query', Array)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 13:14:14 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'id desc limit 10' at line 1
#0 C:\xampp\htdocs\crawlerstand\system\Database\MySQLi\Connection.php(329): mysqli->query('Select * from v...')
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(737): CodeIgniter\Database\MySQLi\Connection->execute('Select * from v...')
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(665): CodeIgniter\Database\BaseConnection->simpleQuery('Select * from v...')
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(1679): CodeIgniter\Database\BaseConnection->query('Select * from v...')
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): CodeIgniter\Model->__call('query', Array)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 13:14:17 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'id limit 10' at line 1
#0 C:\xampp\htdocs\crawlerstand\system\Database\MySQLi\Connection.php(329): mysqli->query('Select * from v...')
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(737): CodeIgniter\Database\MySQLi\Connection->execute('Select * from v...')
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(665): CodeIgniter\Database\BaseConnection->simpleQuery('Select * from v...')
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(1679): CodeIgniter\Database\BaseConnection->query('Select * from v...')
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): CodeIgniter\Model->__call('query', Array)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 13:37:52 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) from vehicles' at line 1
#0 C:\xampp\htdocs\crawlerstand\system\Database\MySQLi\Connection.php(329): mysqli->query('Select count (*...')
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(737): CodeIgniter\Database\MySQLi\Connection->execute('Select count (*...')
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(665): CodeIgniter\Database\BaseConnection->simpleQuery('Select count (*...')
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(1679): CodeIgniter\Database\BaseConnection->query('Select count (*...')
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): CodeIgniter\Model->__call('query', Array)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 13:38:01 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'from vehicles' at line 1
#0 C:\xampp\htdocs\crawlerstand\system\Database\MySQLi\Connection.php(329): mysqli->query('Select count * ...')
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(737): CodeIgniter\Database\MySQLi\Connection->execute('Select count * ...')
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(665): CodeIgniter\Database\BaseConnection->simpleQuery('Select count * ...')
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(1679): CodeIgniter\Database\BaseConnection->query('Select count * ...')
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(9): CodeIgniter\Model->__call('query', Array)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 13:38:15 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'from vehicles' at line 1
#0 C:\xampp\htdocs\crawlerstand\system\Database\MySQLi\Connection.php(329): mysqli->query('Select count * ...')
#1 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(737): CodeIgniter\Database\MySQLi\Connection->execute('Select count * ...')
#2 C:\xampp\htdocs\crawlerstand\system\Database\BaseConnection.php(665): CodeIgniter\Database\BaseConnection->simpleQuery('Select count * ...')
#3 C:\xampp\htdocs\crawlerstand\system\Model.php(1679): CodeIgniter\Database\BaseConnection->query('Select count * ...')
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(10): CodeIgniter\Model->__call('query', Array)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 13:39:01 --> Object of class stdClass could not be converted to string
#0 C:\xampp\htdocs\crawlerstand\app\Views\crawler.php(117): CodeIgniter\Debug\Exceptions->errorHandler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 117, Array)
#1 C:\xampp\htdocs\crawlerstand\system\View\View.php(235): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\crawlerstand\system\Common.php(175): CodeIgniter\View\View->render('crawler', Array, NULL)
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\CrawlerController.php(11): view('crawler', Array)
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 13:39:22 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::get_result()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 13:41:23 --> syntax error, unexpected ')'
#0 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 13:41:30 --> syntax error, unexpected ')'
#0 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 13:41:40 --> syntax error, unexpected ')'
#0 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(798): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2019-11-13 15:33:23 --> Class 'App\Controllers\DOMDocument' not found
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(9): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:34:01 --> Class 'App\Controllers\DOMDocument' not found
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(10): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:35:37 --> Class 'App\Controllers\DomXPath' not found
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(11): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:41:17 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(47): App\Controllers\UrlController->save()
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 15:41:35 --> Call to undefined method App\Controllers\UrlController::query()
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(47): App\Controllers\UrlController->save()
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 15:42:04 --> Call to undefined function App\Controllers\getRow()
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(47): App\Controllers\UrlController->save()
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 15:44:15 --> syntax error, unexpected 'exit' (T_EXIT), expecting ',' or ';'
#0 C:\xampp\htdocs\crawlerstand\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('UrlController')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('UrlController')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:44:27 --> syntax error, unexpected 'exit' (T_EXIT), expecting ',' or ';'
#0 C:\xampp\htdocs\crawlerstand\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('UrlController')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('UrlController')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:53:06 --> Call to undefined method App\Controllers\UrlController::getCount()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 15:53:16 --> Call to undefined method App\Controllers\UrlController::getCount()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 15:58:13 --> Class name must be a valid object or a string
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(14): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:58:24 --> Class name must be a valid object or a string
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(14): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:58:49 --> Class name must be a valid object or a string
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(14): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:58:50 --> Class name must be a valid object or a string
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(14): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:59:02 --> Class name must be a valid object or a string
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(14): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:59:23 --> syntax error, unexpected '}', expecting ';'
#0 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(339): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\crawlerstand\system\Autoloader\Autoloader.php(263): CodeIgniter\Autoloader\Autoloader->loadLegacy('CrawlerControll...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('CrawlerControll...')
#3 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(54): spl_autoload_call('CrawlerControll...')
#4 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(14): App\Controllers\UrlController->processUrl()
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#6 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#7 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#9 {main}
CRITICAL - 2019-11-13 15:59:40 --> Class 'CrawlerController' not found
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(14): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 15:59:55 --> Call to undefined method App\Controllers\CrawlerController::get()
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(55): App\Controllers\CrawlerController->processHtml('https://www.sta...')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(14): App\Controllers\UrlController->processUrl()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:00:21 --> Call to undefined method App\Controllers\CrawlerController::get()
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(54): App\Controllers\CrawlerController->processHtml('https://www.sta...')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(13): App\Controllers\UrlController->processUrl()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:00:31 --> Call to undefined method App\Controllers\CrawlerController::get()
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(55): App\Controllers\CrawlerController->processHtml('https://www.sta...')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(14): App\Controllers\UrlController->processUrl()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:06:41 --> Call to a member function segment() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:08:02 --> Call to a member function segment() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(13): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:10:27 --> Call to a member function segment() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:12:59 --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead)
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-11-13 16:13:08 --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead)
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-11-13 16:13:17 --> Call to a member function segment() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:14:42 --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead)
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-11-13 16:14:45 --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead)
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-11-13 16:14:51 --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead)
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-11-13 16:15:01 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:16:07 --> Call to a member function getSegment() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:16:21 --> Call to a member function getSegment() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:16:48 --> Call to a member function getTotalSegments() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:18:05 --> Call to a member function getSegment() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:18:52 --> Function name must be a string
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:19:02 --> Call to a member function getHost() on string
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:20:01 --> Call to a member function getHost() on string
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(13): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:23:15 --> Call to a member function getSegment() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:23:30 --> Call to undefined method App\Controllers\UrlController::getSegment()
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:24:13 --> Call to a member function getTotalSegments() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 16:26:16 --> Request URI segment is our of range: {0}
#0 C:\xampp\htdocs\crawlerstand\system\HTTP\URI.php(484): CodeIgniter\HTTP\Exceptions\HTTPException::forURISegmentOutOfRange(2)
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(57): CodeIgniter\HTTP\URI->getSegment(2)
#2 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-11-13 16:26:24 --> Request URI segment is our of range: {0}
#0 C:\xampp\htdocs\crawlerstand\system\HTTP\URI.php(484): CodeIgniter\HTTP\Exceptions\HTTPException::forURISegmentOutOfRange(2)
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(57): CodeIgniter\HTTP\URI->getSegment(2)
#2 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-11-13 16:26:37 --> Request URI segment is our of range: {0}
#0 C:\xampp\htdocs\crawlerstand\system\HTTP\URI.php(484): CodeIgniter\HTTP\Exceptions\HTTPException::forURISegmentOutOfRange(2)
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(57): CodeIgniter\HTTP\URI->getSegment(2, 0)
#2 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(12): App\Controllers\UrlController->processUrl()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-11-13 16:26:48 --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead)
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-11-13 16:30:22 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:31:26 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:34:32 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index()
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:35:26 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:35:34 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:36:39 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:36:54 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:37:07 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:37:47 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:38:13 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:38:20 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::get() must be of the type int or null, string given, called in C:\xampp\htdocs\crawlerstand\system\Model.php on line 1683
#0 C:\xampp\htdocs\crawlerstand\system\Model.php(1683): CodeIgniter\Database\BaseBuilder->get('page')
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): CodeIgniter\Model->__call('get', Array)
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 16:43:53 --> {0, string} route cannot be found while reverse-routing.
#0 C:\xampp\htdocs\crawlerstand\system\HTTP\RedirectResponse.php(91): CodeIgniter\HTTP\Exceptions\HTTPException::forInvalidRedirectRoute('')
#1 C:\xampp\htdocs\crawlerstand\system\Common.php(892): CodeIgniter\HTTP\RedirectResponse->route(false)
#2 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): redirect('/user-home')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-11-13 16:44:21 --> {0, string} route cannot be found while reverse-routing.
#0 C:\xampp\htdocs\crawlerstand\system\HTTP\RedirectResponse.php(91): CodeIgniter\HTTP\Exceptions\HTTPException::forInvalidRedirectRoute('')
#1 C:\xampp\htdocs\crawlerstand\system\Common.php(892): CodeIgniter\HTTP\RedirectResponse->route(false)
#2 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(15): redirect('UrlControlle/in...')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->index('3')
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#5 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#7 {main}
CRITICAL - 2019-11-13 17:06:56 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:07:02 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:07:08 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:07:10 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:13 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:15 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:17 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:19 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:22 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:23 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:24 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:27 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:30 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:39 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:40 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:41 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:44 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:45 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:48 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:50 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:52 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:54 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:56 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:20:58 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:11 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:13 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:15 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:17 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:19 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:21 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:23 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:25 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:27 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:29 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:31 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:33 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:33 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls('3')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:22:35 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:23:08 --> Invalid argument supplied for foreach()
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(29): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 29, Array)
#1 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(21): App\Controllers\UrlController->processUrl()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls('3')
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#4 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2019-11-13 17:23:34 --> Call to a member function processHtml() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(19): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:23:35 --> Call to a member function processHtml() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(19): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:23:36 --> Call to a member function processHtml() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(19): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:24:23 --> Call to a member function processHtml() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(19): App\Controllers\UrlController->processUrl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:24:45 --> Call to a member function query() on null
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\UrlController.php(19): App\Controllers\UrlController->processUrl(Object(App\Controllers\CrawlerController))
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls('3')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:25:14 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls('3')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:25:18 --> Call to a member function countAll() on array
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\UrlController->searchUrls('3')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UrlController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:32:41 --> Call to a member function processHtml() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:33:00 --> Call to a member function processHtml() on null
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:33:16 --> Object of class CodeIgniter\HTTP\Response could not be converted to string
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-11-13 17:34:53 --> Object of class CodeIgniter\HTTP\Response could not be converted to string
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-11-13 17:36:32 --> Class 'App\Controllers\CrawlerModel' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:36:36 --> Class 'App\Models\CrawlerModel' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\CrawlerController->index()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\CrawlerController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:42:35 --> Call to undefined method App\Controllers\VehicleController::getCon()
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\VehicleController.php(22): App\Controllers\VehicleController->getNextCrawl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:44:11 --> Cannot use object of type stdClass as array
#0 C:\xampp\htdocs\crawlerstand\app\Controllers\VehicleController.php(22): App\Controllers\VehicleController->getNextCrawl()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:46:12 --> syntax error, unexpected ';'
#0 C:\xampp\htdocs\crawlerstand\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('VehicleControll...')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('VehicleControll...')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:46:22 --> syntax error, unexpected ';'
#0 C:\xampp\htdocs\crawlerstand\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('VehicleControll...')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('VehicleControll...')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:46:35 --> syntax error, unexpected ';'
#0 C:\xampp\htdocs\crawlerstand\system\Router\Router.php(191): CodeIgniter\Router\Router->autoRoute('VehicleControll...')
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(722): CodeIgniter\Router\Router->handle('VehicleControll...')
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(295): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2019-11-13 17:47:19 --> Call to undefined method App\Controllers\VehicleController::isValid()
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:54:54 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:54:57 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:55:00 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:55:00 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:55:03 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:55:04 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:55:10 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:55:12 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:55:14 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:55:16 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2019-11-13 17:55:37 --> Class 'App\Controllers\Vehicle' not found
#0 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(844): App\Controllers\VehicleController->crawlVehicle()
#1 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\VehicleController))
#2 C:\xampp\htdocs\crawlerstand\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\crawlerstand\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
